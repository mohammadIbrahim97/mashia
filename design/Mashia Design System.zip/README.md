# Mashia Design System

> A regional sheep-livestock marketplace for the Gulf and Levant.
> *Mashia (مشية) — Arabic for "desire / what is wanted."*

---

## What Mashia is

Mashia connects verified **sellers, buyers, and brokers** across the Gulf and Levant in a livestock marketplace built around trust:

- **Listings** carry breed, weight, age, and veterinary-certificate metadata.
- **Negotiation** happens in real-time chat between traders and brokers.
- **Escrow-backed orders** — payments held until delivery is confirmed (auto-released after 7 days).
- **Compliance** — KYC for traders, halal & health certificates for animals.
- **Region** — hosted on AWS Bahrain (`me-south-1`) for low-latency in the Levant + GCC.

### Products / surfaces in the system

The platform ships in three pieces:

| Surface | Stack | Audience |
|---|---|---|
| **Mobile app** | React Native | Traders (sellers, buyers, brokers) — primary surface |
| **Admin dashboard** | Next.js | Moderators, KYC reviewers, support |
| **Backend** | NestJS | Auth, listings, orders, escrow, messaging |

This design system covers the two visual surfaces (mobile + admin). The backend is referenced for naming/data shape but has no UI.

---

## Sources used to build this system

- **Brand guide:** `uploads/mashia-brand-guide.html` — authored Mashia Brand Guide v1.0, 2026 edition. Contains color palette, type pairing, application examples in LTR + RTL, and accessibility notes. Inspired by the Syrian National Visual Identity (July 2025) and the shared green of the Syrian/Saudi flags.
- **Product description:** the project brief (sheep marketplace, escrow, KYC, halal certs, three-piece platform).
- **No codebase or Figma was provided.** UI kit components below are designed against the brand guide and product domain — they are well-aligned mocks rather than recreations of existing screens. **If you have the actual RN/Next codebase or Figma, please share it so we can replace the kits with code-faithful versions.**

---

## Index — what's in this folder

```
README.md                    ← you are here
SKILL.md                     ← Agent Skill descriptor (Claude Code-compatible)
colors_and_type.css          ← single source of truth for tokens

assets/                      ← logos, icons, sample imagery
preview/                     ← cards rendered in the Design System tab
ui_kits/
  mobile/                    ← React Native trader app — JSX components + index.html prototype
  admin/                     ← Next.js admin dashboard — JSX components + index.html prototype
uploads/                     ← original brand guide source
```

Quick links:
- Tokens: [`colors_and_type.css`](./colors_and_type.css)
- Mobile UI kit: [`ui_kits/mobile/index.html`](./ui_kits/mobile/index.html)
- Admin UI kit: [`ui_kits/admin/index.html`](./ui_kits/admin/index.html)
- Original brand guide: [`uploads/mashia-brand-guide.html`](./uploads/mashia-brand-guide.html)

---

## Content Fundamentals

Mashia's voice is **honest, plainspoken, and bilingual-first**. It sits between editorial warmth (the brand has heritage cues) and the hard practicality of a working marketplace where money and animals change hands.

### Tone & vibe
- **Confident, not loud.** Says one true thing, then stops.
- **Editorial when the moment allows** (marketing pages, empty states, onboarding) — short, lyrical, present-tense.
- **Operational and direct in product** (forms, list items, transactional flows). No jargon, no "synergy."
- **Generous with space, sparing with words.** A button is "Place order →" not "Click here to submit your order request."

### Person & address
- **"You" / second person** for the trader. Never "we" in product copy unless explicitly speaking as the platform ("We hold your payment until delivery is confirmed.").
- **Imperative for actions:** *Place order. Verify ID. Upload certificate.*
- **Past tense for confirmations:** *Order placed. Funds escrowed. Payment released.*

### Casing
- **Sentence case everywhere.** Buttons, headings, table columns, navigation. No Title Case.
- **UPPERCASE only for mono-spaced labels** (section numerals, metadata, "BRAND GUIDE"-style overlines). Always paired with `letter-spacing: 0.12–0.22em`.
- **Numerals:** Western digits in LTR copy, Arabic-Indic (٠١٢٣٤٥٦٧٨٩) inside Arabic copy. Currency follows the user's locale (SAR, AED, BHD).

### Bilingual rules
- **Arabic is first-class, not a translation.** Every screen ships in both languages with full RTL mirroring.
- **Don't transliterate** — *مشية* not *Mashia* in Arabic copy.
- **Currency, dates, animal counts** localize per locale; don't pretend a Saudi user reads dirhams.

### Emoji & symbols
- **No emoji.** The brand reads as editorial; emoji break the register.
- **Unicode arrows are welcome** (→ ← ↗) — they pair with Fraunces italics and feel typographic, not decorative.
- **Bullets:** prefer em-dashes or hairline rules over • in editorial copy.

### Voice examples

| Don't | Do |
|---|---|
| "Awesome! Your listing is live 🎉" | "Listing published." |
| "Click here to submit" | "Place order →" |
| "We're sorry, something went wrong." | "Couldn't reach the server. Try again." |
| "Buy premium sheep now!" | "Najdi ewes, 6 head, Riyadh." |
| "Your funds are safe with us!" | "Payment held in escrow until delivery is confirmed." |

### Signature moments
- **Wordmark sign-offs** in editorial places (footers, splashes): *Mashia.* with the trailing period in Fraunces italic.
- **Section numerals** as `01 · CONCEPT`, `02 · COLOR` — ordinal + interpunct + uppercase mono. A consistent scaffolding pattern across long-form pages.
- **Escrow language** is plain English: "held," "released," "auto-released after 7 days." Never "escrow protocol," never "smart contract."

---

## Visual Foundations

### The big idea

One dominant green, anchored to the shared green of the Syrian and Saudi flags. Five heritage accents drawn from Syrian terrain — gold, sand, bronze, river-green, sea-blue, basalt. The brand reads **editorial-modern**: serif display + clean geometric body, generous whitespace, restrained color use, square corners with one or two surface treatments that hint at heritage (paper grain, parchment cards).

### Color

- **Dominant:** Mashia 600 `#007339` — the brand core. Used for primary buttons, link accents, brand surfaces, status: verified.
- **Neutrals:** Paper `#FBF8F1` (default surface), Parchment `#F6F1E7` (raised cards), Ink `#14181A` (body text), Basalt Black `#1A1E1B` (dark surfaces).
- **Accents (sparingly):** Qasioun Gold `#C9974A` for one-off CTAs and highlights — *never two on the same screen.* Med Blue, Bronze, Orontes Green, Sand for editorial moments.
- **60 / 25 / 12 / 3 split:** green / neutral / gold / other. Keeps the brand recognizably green while leaving room for warmth and information.
- **Dark mode:** Brand green shifts up to Mashia 400 `#3FA068` for AA legibility on Basalt. Body text uses Palmyra Sand `#DECDA6` instead of pure white — softer on the eye.

### Type

- **Display:** Fraunces (Latin) + Reem Kufi (Arabic). Italic Fraunces is a brand signature — used for emphasis inside display text and as an accent voice.
- **Body:** Manrope (Latin) + Reem Kufi (Arabic). Reem Kufi covers both Arabic display and body in this system; pair its lighter weights (400/500) with Manrope at the same optical size.
- **Mono:** JetBrains Mono. Used only for metadata labels, section numerals, and code/IDs — never body.
- **Self-hosted:** Fraunces, Manrope, and Reem Kufi ship as variable TTFs in `/fonts` and are wired up via `@font-face` in `colors_and_type.css`. JetBrains Mono is the one family still pulled from Google Fonts.

### Backgrounds & surfaces

- **No gradients in product UI.** Hero uses a single radial vignette (gold→transparent) on solid green; that's the limit.
- **Paper grain** as a subtle texture: two stacked low-opacity radial-gradient dot patterns on `--paper`. Used on long-form and brand surfaces, not on dense data UI.
- **Full-bleed image hero** allowed on marketing/onboarding only. Imagery should feel **warm, slightly desaturated, golden-hour** — not glossy stock. Sheep imagery: pastoral, mid-distance, never close-up muzzle shots.
- **Cards are flat by default** — Parchment fill, hairline border, no shadow. Elevation appears only when a card is dragged or in a modal.

### Borders, radii & shadows

- **Square corners are the default** (`--radius-0`). Mashia is editorial-square, not playful-rounded.
- **Hairline borders:** `rgba(20,24,26,0.12)`. Used liberally to define structure instead of shadow.
- **Soft 8px radius** only on a few interactive surfaces (mobile cards, sheets) to feel touchable on phones.
- **Pill radius** reserved for status chips and filter pills on mobile.
- **Shadow-1** is the default elevation; **shadow-3** for floating sheets/menus. Avoid drop shadows on light-on-light.

### Spacing & layout

- **4px base.** Most UI lives on 16 / 24 / 32 / 48 / 64 px increments.
- **Editorial pages** breathe: 120px section padding vertical, 48px container horizontal.
- **Product UI** is denser: 16/24px section gaps, 12/16px card padding.
- **Section heads** use a 80px / 1fr grid: numeral + interpunct in mono on the left, display title on the right.
- **Fixed elements** are limited to the rail (56px on desktop / 36px on mobile) and bottom nav on mobile (64px).

### Hover & press

- **Buttons:** primary darkens 600→700 on hover (`--dur-base` ease-out). No scale, no glow.
- **Secondary buttons:** invert on hover — text becomes paper, background becomes ink.
- **Press state on mobile:** opacity 0.7, no scale-down. Quiet.
- **Links in body copy:** Mashia 700, no underline at rest, underline on hover.
- **Cards (touchable):** hairline border darkens to `--hairline-strong` on hover. No shadow lift.

### Motion

- **Quiet by default.** 120–200ms transitions. `cubic-bezier(0.2, 0.7, 0.2, 1)` — fast-out, settle.
- **Fades** for entrances (modals, sheets), not slides.
- **No bounces, no parallax.** Mashia is not playful.
- **Loading:** a thin Mashia-600 progress bar at the top of the surface, or skeleton blocks in `--mashia-50`.

### Transparency & blur

- **Modal scrim:** `rgba(20,24,26,0.55)` with optional 2px backdrop-blur on capable devices.
- **Bottom-nav blur:** `backdrop-filter: blur(12px)` over a 70%-opacity paper background, on mobile.
- **No frosted-glass cards** in the product. The brand is solid surfaces.

### Imagery vibe

- Warm, **golden-hour**, slightly desaturated. Think documentary photography over advertising.
- Animals shown **with their environment** — rangeland, market, a trader's hand on the rope. Not isolated on white.
- **Black & white** acceptable for editorial moments (e.g. About page, "Our story" surfaces). Not in product.

### Iconography (overview — see ICONOGRAPHY below)

- **Lucide** stroke icons at 1.5px weight — they read editorial and pair well with Fraunces.
- Icons are `--ink` at rest, `--accent` when active, `--muted` when disabled. Never colored except for status icons.
- **No filled icon variants** in the system except for status badges (verified ✓ checkmark in solid green circle).

### RTL

- **First-class.** Every layout must mirror; Arabic is not a translation, it's a parallel script.
- Use logical properties (`margin-inline-start`, etc.) not directional ones.
- The wordmark itself flips to *مشية* in RTL contexts; do not show "Mashia" Latin in Arabic-only surfaces.

---

## Iconography

Mashia ships **without a custom icon font**. The brand-guide source uses inline glyphs and Unicode arrows only.

### Icon system in use

- **Library:** [Lucide](https://lucide.dev) — 1.5px stroke weight, `currentColor`, square caps. Editorial, not chunky.
- **Why Lucide:** open source, regional/cultural neutral, pairs with Fraunces' weight without competing. Same family covers mobile (RN via `lucide-react-native`) and admin (web via `lucide-react`).
- **Loading:** CDN `https://unpkg.com/lucide@latest` for prototypes, npm package for production.

> **⚠️ Substitution flag:** No first-party icon set was provided. Lucide is a substitute chosen for editorial fit. If Mashia commissions or already has a custom icon set, drop the SVGs into `assets/icons/` and update this file.

### Sizing

| Context | Size |
|---|---|
| Inline with body text | 16px |
| Buttons, list rows | 20px |
| Tab bar, primary nav | 24px |
| Empty-state hero | 48–64px |

### Color rules

- Default: `currentColor` so icons inherit the surrounding text color.
- Active / selected: `--mashia-600`.
- Status icons get explicit colors: verified `--mashia-600`, pending `--qasioun-gold`, flagged `--status-flagged`.

### Logo

The Mashia wordmark is a **typographic mark** — Fraunces "Mash" + italic Fraunces "ia" + a Latin trailing period in editorial moments. Arabic mark is *مشية* in Reem Kufi. SVG renderings live in `assets/`.

### Emoji & Unicode

- **No emoji.** Anywhere.
- **Unicode arrows** (→ ← ↗ ↘) are encouraged in marketing/editorial copy and CTA buttons. They are typographic, not decorative.
- **Status indicators** use SVG icon + color, not Unicode symbols (avoid ✓ ✗ outside of decorative contexts).

---

## Caveats & open questions

- **Fonts:** Fraunces, Manrope, and Reem Kufi are bundled as variable TTFs in `/fonts` and self-hosted via `@font-face` in `colors_and_type.css`. JetBrains Mono is still pulled from Google Fonts — drop a TTF/WOFF2 into `/fonts` and add a fourth `@font-face` if you need a fully offline build. Tajawal was previously listed as the Arabic body face but has been retired in favor of Reem Kufi covering both Arabic roles.
- **Icons:** Lucide is a substitute. If Mashia has a commissioned icon set, drop SVGs into `assets/icons/` and update the iconography section.
- **No codebase or Figma was attached.** UI kits are designed against the brand guide and the product description (sheep marketplace, escrow, KYC, halal certs) — not against real RN/Next code. **If you have either, share it and we can replace these with code-faithful recreations.**
- **Imagery:** All listing images in the prototypes are gradient placeholders. The brand calls for warm, golden-hour pastoral photography — please supply or commission.
- **Heritage accent HEX values** in the brand guide are noted as visual approximations of the Syrian National Visual Identity (July 2025); update when the official brand book HEXes are published.


