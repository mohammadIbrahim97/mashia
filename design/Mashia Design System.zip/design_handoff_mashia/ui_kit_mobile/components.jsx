// Mashia Mobile · Shared atomic UI components
// React global is available via <script src> tag

const { useState, useEffect } = React;

const M_GREEN = '#007339';
const M_GREEN_700 = '#005C2E';
const M_GREEN_50 = '#ECF7F0';
const PAPER = '#FBF8F1';
const PARCHMENT = '#F6F1E7';
const INK = '#14181A';
const MUTED = '#6B6E66';
const HAIRLINE = 'rgba(20,24,26,0.12)';
const GOLD = '#C9974A';
const SAND = '#DECDA6';
const BASALT = '#1A1E1B';

// Lucide-style stroke icons (1.5px, currentColor)
function Icon({ name, size = 22, color }) {
  const props = {
    width: size, height: size, viewBox: '0 0 24 24',
    fill: 'none', stroke: color || 'currentColor',
    strokeWidth: 1.5, strokeLinecap: 'round', strokeLinejoin: 'round',
  };
  const paths = {
    home: <><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></>,
    search: <><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></>,
    message: <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>,
    user: <><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></>,
    plus: <><path d="M12 5v14M5 12h14"/></>,
    check: <path d="M20 6 9 17l-5-5"/>,
    chevronRight: <polyline points="9 18 15 12 9 6"/>,
    chevronLeft: <polyline points="15 18 9 12 15 6"/>,
    mapPin: <><path d="M12 22s-8-4.5-8-11.8A5.5 5.5 0 0 1 12 4a5.5 5.5 0 0 1 8 6.2C20 17.5 12 22 12 22z"/><circle cx="12" cy="10" r="3"/></>,
    filter: <polygon points="22 3 2 3 10 12.5 10 19 14 21 14 12.5 22 3"/>,
    clock: <><circle cx="12" cy="12" r="10"/><path d="M12 8v4l3 2"/></>,
    shield: <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>,
    bell: <><path d="M6 8a6 6 0 1 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10 21a2 2 0 0 0 4 0"/></>,
    wallet: <><path d="M19 7H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/><path d="M16 14h.01M3 9V7a2 2 0 0 1 2-2h11"/></>,
    send: <><path d="m22 2-7 20-4-9-9-4z"/><path d="M22 2 11 13"/></>,
    image: <><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></>,
    arrowRight: <><path d="M5 12h14M12 5l7 7-7 7"/></>,
  };
  return <svg {...props}>{paths[name]}</svg>;
}

// Status chip — pill, mono label
function Chip({ kind = 'neutral', children }) {
  const styles = {
    verified: { bg: M_GREEN_50, fg: M_GREEN_700, dot: M_GREEN, border: '#A4D6B8' },
    pending:  { bg: '#FBF1DD', fg: '#8A6418', dot: GOLD, border: '#E8CB8E' },
    released: { bg: M_GREEN_50, fg: M_GREEN, dot: '#1A8649', border: '#A4D6B8' },
    flagged:  { bg: '#F8E5E5', fg: '#8A2828', dot: '#B23B3B', border: '#EBC0C0' },
    info:     { bg: '#E5EEF5', fg: '#1F5F8F', dot: '#1F5F8F', border: '#BDD2E2' },
    neutral:  { bg: PAPER, fg: INK, dot: null, border: HAIRLINE },
  }[kind];
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px',
      borderRadius: 999, fontFamily: 'Manrope, sans-serif', fontWeight: 600, fontSize: 11,
      background: styles.bg, color: styles.fg, border: `1px solid ${styles.border}`,
    }}>
      {styles.dot && <span style={{ width: 5, height: 5, borderRadius: 999, background: styles.dot }} />}
      {children}
    </span>
  );
}

// Mono overline
function Overline({ children, color }) {
  return <div style={{
    fontFamily: 'JetBrains Mono, monospace', fontSize: 10,
    letterSpacing: '0.16em', textTransform: 'uppercase',
    color: color || MUTED,
  }}>{children}</div>;
}

// Primary button
function Button({ kind = 'primary', children, onClick, full, icon }) {
  const styles = {
    primary: { bg: M_GREEN, fg: PAPER, border: 'transparent' },
    secondary: { bg: 'transparent', fg: INK, border: INK },
    ghost: { bg: 'transparent', fg: M_GREEN, border: 'transparent' },
    accent: { bg: GOLD, fg: BASALT, border: 'transparent' },
  }[kind];
  return (
    <button onClick={onClick} style={{
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
      padding: '14px 22px', fontFamily: 'Manrope, sans-serif', fontWeight: 600, fontSize: 15,
      background: styles.bg, color: styles.fg, border: `1px solid ${styles.border}`,
      cursor: 'pointer', width: full ? '100%' : 'auto', borderRadius: 8,
      transition: 'all 200ms cubic-bezier(0.2,0.7,0.2,1)',
    }}>
      {children}
      {icon && <Icon name={icon} size={18} />}
    </button>
  );
}

// Listing image placeholder — gradient with ovine vibe
function ListingImage({ tone = 'green', tall }) {
  const tones = {
    green: 'linear-gradient(135deg, #A4D6B8, #5C9856)',
    sand:  'linear-gradient(135deg, #DECDA6, #C9974A)',
    bronze:'linear-gradient(135deg, #DECDA6, #7C5234)',
    cool:  'linear-gradient(135deg, #C7D6E0, #1F5F8F)',
  };
  return (
    <div style={{
      width: '100%', aspectRatio: tall ? '4/3' : '4/2.2',
      background: tones[tone], borderRadius: 6, position: 'relative', overflow: 'hidden',
    }}>
      {/* subtle horizon line */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'linear-gradient(180deg, transparent 60%, rgba(20,24,26,0.18) 100%)',
      }}/>
    </div>
  );
}

// Listing card (vertical)
function ListingCard({ listing, onClick }) {
  return (
    <div onClick={onClick} style={{
      background: PAPER, border: `1px solid ${HAIRLINE}`, borderRadius: 8,
      padding: 10, cursor: 'pointer',
    }}>
      <ListingImage tone={listing.tone} />
      <div style={{ marginTop: 10, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
        {listing.featured && <Chip kind="pending">Featured</Chip>}
        {listing.verified && <Chip kind="verified">Vet ✓</Chip>}
      </div>
      <div style={{
        fontFamily: 'Fraunces, serif', fontSize: 17, fontWeight: 500, lineHeight: 1.2,
        color: INK, marginTop: 8,
      }}>{listing.title}</div>
      <div style={{ fontSize: 12, color: MUTED, marginTop: 3 }}>
        {listing.region} · {listing.weight}
      </div>
      <div style={{
        fontFamily: 'Fraunces, serif', fontWeight: 600, fontSize: 16,
        color: M_GREEN_700, marginTop: 8,
      }}>{listing.price}</div>
    </div>
  );
}

// Bottom navigation bar
function BottomNav({ active, onChange }) {
  const items = [
    { id: 'home', icon: 'home', label: 'Home' },
    { id: 'browse', icon: 'search', label: 'Browse' },
    { id: 'sell', icon: 'plus', label: 'Sell' },
    { id: 'chat', icon: 'message', label: 'Chat' },
    { id: 'me', icon: 'user', label: 'Me' },
  ];
  return (
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0,
      height: 76, background: 'rgba(251,248,241,0.92)',
      backdropFilter: 'blur(12px)',
      borderTop: `1px solid ${HAIRLINE}`,
      display: 'flex', justifyContent: 'space-around', alignItems: 'flex-start',
      paddingTop: 8, paddingBottom: 18,
    }}>
      {items.map(it => {
        const selected = it.id === active;
        const isPrimary = it.id === 'sell';
        if (isPrimary) {
          return (
            <button key={it.id} onClick={() => onChange(it.id)} style={{
              background: M_GREEN, color: PAPER, border: 'none', borderRadius: 999,
              width: 48, height: 48, display: 'flex', alignItems: 'center', justifyContent: 'center',
              marginTop: -8, cursor: 'pointer',
              boxShadow: '0 4px 12px -4px rgba(0,115,57,0.4)',
            }}>
              <Icon name="plus" size={22} color={PAPER}/>
            </button>
          );
        }
        return (
          <button key={it.id} onClick={() => onChange(it.id)} style={{
            background: 'transparent', border: 'none', cursor: 'pointer',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
            color: selected ? M_GREEN : MUTED,
          }}>
            <Icon name={it.icon} size={22} />
            <span style={{
              fontFamily: 'Manrope, sans-serif', fontSize: 10, fontWeight: 600,
              letterSpacing: '0.04em',
            }}>{it.label}</span>
          </button>
        );
      })}
    </div>
  );
}

// Top app bar
function AppBar({ title, left, right, ar }) {
  return (
    <div style={{
      height: 52, padding: '0 16px',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      borderBottom: `1px solid ${HAIRLINE}`, background: PAPER,
    }}>
      <div style={{ width: 28 }}>{left}</div>
      <div style={{
        fontFamily: ar ? 'Reem Kufi, serif' : 'Fraunces, serif',
        fontSize: 18, fontWeight: 500, color: INK, direction: ar ? 'rtl' : 'ltr',
      }}>{title}</div>
      <div style={{ width: 28, textAlign: 'right' }}>{right}</div>
    </div>
  );
}

// Section header (mono numeral + title)
function SectionHeader({ num, title, action }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
      padding: '20px 16px 10px',
    }}>
      <div>
        {num && <Overline>{num}</Overline>}
        <div style={{
          fontFamily: 'Fraunces, serif', fontSize: 22, fontWeight: 500,
          letterSpacing: '-0.01em', color: INK, marginTop: num ? 4 : 0,
        }}>{title}</div>
      </div>
      {action && <div style={{
        fontFamily: 'Manrope, sans-serif', fontSize: 13, fontWeight: 600, color: M_GREEN,
      }}>{action}</div>}
    </div>
  );
}

// Search field
function SearchField({ value, onChange, placeholder }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 8,
      background: PARCHMENT, border: `1px solid ${HAIRLINE}`, borderRadius: 8,
      padding: '10px 12px',
    }}>
      <Icon name="search" size={18} color={MUTED}/>
      <input
        value={value || ''} onChange={e => onChange && onChange(e.target.value)}
        placeholder={placeholder || 'Search'}
        style={{
          flex: 1, background: 'transparent', border: 'none', outline: 'none',
          fontFamily: 'Manrope, sans-serif', fontSize: 14, color: INK,
        }}
      />
      <Icon name="filter" size={18} color={MUTED}/>
    </div>
  );
}

Object.assign(window, {
  Icon, Chip, Overline, Button, ListingImage, ListingCard,
  BottomNav, AppBar, SectionHeader, SearchField,
  M_GREEN, M_GREEN_700, M_GREEN_50, PAPER, PARCHMENT, INK, MUTED, HAIRLINE, GOLD, SAND, BASALT,
});
