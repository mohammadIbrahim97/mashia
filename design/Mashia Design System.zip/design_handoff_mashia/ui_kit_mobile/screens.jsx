// Mashia Mobile · Screens
const { useState: useStateS } = React;

// Home screen — feed of listings
function HomeScreen({ goTo }) {
  const featured = [
    { id: 1, title: 'Najdi ewes, 6 head', region: 'Riyadh', weight: '38–42 kg', price: '14,400 SAR', tone: 'green', verified: true, featured: true },
    { id: 2, title: 'Awassi rams, 12 head', region: 'Damascus', weight: '55 kg avg', price: '8,800 USD', tone: 'sand', verified: true },
    { id: 3, title: 'Harri lambs, 4 head', region: 'Dubai', weight: '22 kg', price: '4,200 AED', tone: 'bronze', verified: true },
    { id: 4, title: 'Sawakni breeding', region: 'Manama', weight: '60 kg', price: '6,400 BHD', tone: 'cool', verified: false },
  ];
  return (
    <div style={{ paddingBottom: 96, background: PARCHMENT, minHeight: '100%' }}>
      <AppBar
        title={<span>Mash<em style={{fontStyle:'italic',color:GOLD}}>ia</em></span>}
        left={<Icon name="bell" size={20}/>}
        right={<Icon name="mapPin" size={20}/>}
      />
      <div style={{ padding: '14px 16px 0' }}>
        <SearchField placeholder="Najdi, Awassi, Riyadh…"/>
      </div>

      {/* Filter chips */}
      <div style={{ display: 'flex', gap: 8, padding: '14px 16px 0', overflowX: 'auto' }}>
        <Chip kind="verified">All</Chip>
        <Chip kind="neutral">Najdi</Chip>
        <Chip kind="neutral">Awassi</Chip>
        <Chip kind="neutral">Harri</Chip>
        <Chip kind="info">Halal cert</Chip>
      </div>

      <SectionHeader num="01 · NEAR YOU" title="In Riyadh today" action="See all →"/>
      <div style={{ padding: '0 16px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        {featured.map(l => <ListingCard key={l.id} listing={l} onClick={() => goTo('detail', l)}/>)}
      </div>

      {/* Editorial banner */}
      <div style={{
        margin: '20px 16px 0', padding: 20,
        background: BASALT, color: PAPER, borderRadius: 8,
      }}>
        <Overline color={GOLD}>● BROKER NETWORK</Overline>
        <div style={{
          fontFamily: 'Fraunces, serif', fontSize: 20, fontWeight: 400,
          marginTop: 8, lineHeight: 1.25,
        }}>
          A green thread between <em style={{color:GOLD}}>Sham</em> and the Hejaz.
        </div>
        <div style={{ fontSize: 12, color: SAND, marginTop: 8, lineHeight: 1.55 }}>
          Verified sellers, escrow on every order, halal certificates baked in.
        </div>
      </div>

      <SectionHeader num="02 · TRUSTED" title="Featured brokers"/>
      <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 8 }}>
        {[{n: 'Yasir Al-Otaibi', r: 'Riyadh', d: '142 deals'}, {n: 'Tarek Haddad', r: 'Damascus', d: '98 deals'}].map((b, i) => (
          <div key={i} style={{
            background: PAPER, border: `1px solid ${HAIRLINE}`, borderRadius: 8,
            padding: 12, display: 'flex', alignItems: 'center', gap: 12,
          }}>
            <div style={{
              width: 40, height: 40, borderRadius: 999, background: M_GREEN_50,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: 'Fraunces, serif', fontWeight: 600, color: M_GREEN_700,
            }}>{b.n[0]}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: 'Fraunces, serif', fontSize: 15, fontWeight: 500 }}>{b.n}</div>
              <div style={{ fontSize: 12, color: MUTED }}>{b.r} · {b.d}</div>
            </div>
            <Chip kind="verified">KYC ✓</Chip>
          </div>
        ))}
      </div>
    </div>
  );
}

// Listing detail
function DetailScreen({ listing, goTo }) {
  const l = listing || { title: 'Najdi ewes, 6 head', region: 'Riyadh', weight: '38–42 kg', price: '14,400 SAR', tone: 'green' };
  return (
    <div style={{ paddingBottom: 100, background: PAPER, minHeight: '100%' }}>
      <AppBar
        title="Listing"
        left={<button onClick={()=>goTo('home')} style={{background:'none',border:'none',padding:0,cursor:'pointer'}}><Icon name="chevronLeft" size={22}/></button>}
        right={<Icon name="shield" size={20} color={M_GREEN}/>}
      />
      <div style={{ aspectRatio: '4/3' }}>
        <ListingImage tone={l.tone} tall/>
      </div>
      <div style={{ padding: 16 }}>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          <Chip kind="verified">Vet certificate ✓</Chip>
          <Chip kind="info">Halal cert</Chip>
          <Chip kind="neutral">KYC verified seller</Chip>
        </div>
        <div style={{
          fontFamily: 'Fraunces, serif', fontSize: 28, fontWeight: 500,
          letterSpacing: '-0.015em', marginTop: 14, lineHeight: 1.1,
        }}>{l.title}</div>
        <div style={{ fontSize: 13, color: MUTED, marginTop: 6 }}>
          {l.region} · {l.weight} · listed 2 days ago
        </div>
        <div style={{
          fontFamily: 'Fraunces, serif', fontSize: 32, fontWeight: 600,
          color: M_GREEN_700, marginTop: 16,
        }}>{l.price}</div>

        <div style={{ marginTop: 20, padding: 14, background: PARCHMENT, border: `1px solid ${HAIRLINE}`, borderRadius: 8 }}>
          <Overline color={M_GREEN_700}>● ESCROW PROTECTED</Overline>
          <div style={{ fontSize: 13, color: INK, marginTop: 8, lineHeight: 1.5 }}>
            Payment held in escrow until you confirm delivery. Auto-released after 7 days.
          </div>
        </div>

        <div style={{ marginTop: 20 }}>
          <Overline>METADATA</Overline>
          <div style={{ marginTop: 10 }}>
            {[
              ['Breed', 'Najdi'],
              ['Avg. weight', '40 kg'],
              ['Age', '2 yrs'],
              ['Vet cert ID', 'VC-RY-2K7M'],
              ['Halal cert', 'HCS-024-19'],
            ].map(([k, v]) => (
              <div key={k} style={{
                display: 'flex', justifyContent: 'space-between',
                padding: '10px 0', borderBottom: `1px solid ${HAIRLINE}`,
                fontSize: 13,
              }}>
                <span style={{ color: MUTED }}>{k}</span>
                <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 12, color: INK }}>{v}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0,
        padding: '12px 16px 28px', background: 'rgba(251,248,241,0.95)',
        backdropFilter: 'blur(12px)', borderTop: `1px solid ${HAIRLINE}`,
        display: 'flex', gap: 10,
      }}>
        <Button kind="secondary" onClick={()=>goTo('chat')}>Chat seller</Button>
        <div style={{flex:1}}><Button full kind="primary" icon="arrowRight" onClick={()=>goTo('checkout', l)}>Place order</Button></div>
      </div>
    </div>
  );
}

// Chat screen
function ChatScreen({ goTo }) {
  const [messages, setMessages] = useStateS([
    { from: 'them', text: 'Six head, all vaccinated last month. Cert is uploaded.', t: '14:02' },
    { from: 'me', text: 'Can you do 14,000 SAR? Pickup Friday from Al Kharj.', t: '14:04' },
    { from: 'them', text: '14,200 and I deliver to Riyadh. Final.', t: '14:06' },
  ]);
  const [draft, setDraft] = useStateS('Deal. Sending offer now.');
  const send = () => {
    if (!draft.trim()) return;
    setMessages([...messages, { from: 'me', text: draft, t: '14:08' }]);
    setDraft('');
  };
  return (
    <div style={{ background: PARCHMENT, minHeight: '100%', display: 'flex', flexDirection: 'column' }}>
      <AppBar
        title="Yasir Al-Otaibi"
        left={<button onClick={()=>goTo('home')} style={{background:'none',border:'none',padding:0,cursor:'pointer'}}><Icon name="chevronLeft" size={22}/></button>}
        right={<Icon name="shield" size={20} color={M_GREEN}/>}
      />
      <div style={{
        padding: '8px 16px', background: M_GREEN_50, borderBottom: `1px solid #A4D6B8`,
        fontSize: 12, color: M_GREEN_700, display: 'flex', alignItems: 'center', gap: 8,
      }}>
        <Icon name="shield" size={14} color={M_GREEN}/>
        Negotiating · listing #ORD-2K7M-9F
      </div>
      <div style={{ flex: 1, padding: 16, display: 'flex', flexDirection: 'column', gap: 8 }}>
        {messages.map((m, i) => (
          <div key={i} style={{
            alignSelf: m.from === 'me' ? 'flex-end' : 'flex-start', maxWidth: '78%',
            background: m.from === 'me' ? M_GREEN : PAPER,
            color: m.from === 'me' ? PAPER : INK,
            padding: '10px 14px', borderRadius: 14,
            borderBottomRightRadius: m.from === 'me' ? 4 : 14,
            borderBottomLeftRadius: m.from === 'them' ? 4 : 14,
            border: m.from === 'them' ? `1px solid ${HAIRLINE}` : 'none',
            fontSize: 14, lineHeight: 1.45,
          }}>
            {m.text}
            <div style={{
              fontSize: 10, opacity: 0.7, marginTop: 4,
              fontFamily: 'JetBrains Mono, monospace',
            }}>{m.t}</div>
          </div>
        ))}
      </div>
      <div style={{
        padding: '10px 12px 24px', background: PAPER, borderTop: `1px solid ${HAIRLINE}`,
        display: 'flex', gap: 8, alignItems: 'center',
      }}>
        <Icon name="image" size={20} color={MUTED}/>
        <input
          value={draft} onChange={e => setDraft(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && send()}
          placeholder="Message"
          style={{
            flex: 1, padding: '10px 12px', background: PARCHMENT, border: `1px solid ${HAIRLINE}`,
            borderRadius: 999, fontFamily: 'Manrope, sans-serif', fontSize: 14, outline: 'none',
          }}
        />
        <button onClick={send} style={{
          background: M_GREEN, color: PAPER, border: 'none', borderRadius: 999,
          width: 40, height: 40, display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer',
        }}>
          <Icon name="send" size={18} color={PAPER}/>
        </button>
      </div>
    </div>
  );
}

// Checkout / escrow screen
function CheckoutScreen({ listing, goTo }) {
  const l = listing || { title: 'Najdi ewes, 6 head', price: '14,400 SAR' };
  return (
    <div style={{ paddingBottom: 110, background: PAPER, minHeight: '100%' }}>
      <AppBar
        title="Place order"
        left={<button onClick={()=>goTo('detail', l)} style={{background:'none',border:'none',padding:0,cursor:'pointer'}}><Icon name="chevronLeft" size={22}/></button>}
      />
      <div style={{ padding: 16 }}>
        <Overline>SUMMARY</Overline>
        <div style={{
          marginTop: 10, padding: 14, background: PARCHMENT,
          border: `1px solid ${HAIRLINE}`, borderRadius: 8,
        }}>
          <div style={{ fontFamily: 'Fraunces, serif', fontSize: 17, fontWeight: 500 }}>{l.title}</div>
          <div style={{ fontSize: 12, color: MUTED, marginTop: 4 }}>Seller · Yasir Al-Otaibi</div>
          <div style={{
            display: 'flex', justifyContent: 'space-between',
            marginTop: 14, paddingTop: 12, borderTop: `1px solid ${HAIRLINE}`,
            fontFamily: 'Fraunces, serif', fontSize: 22, fontWeight: 600, color: M_GREEN_700,
          }}>
            <span>Total</span>
            <span>{l.price}</span>
          </div>
        </div>

        <div style={{ marginTop: 22 }}>
          <Overline>● ESCROW · HOW IT WORKS</Overline>
          <div style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 12 }}>
            {[
              ['1', 'Pay into escrow', 'Funds held by Mashia, not the seller.'],
              ['2', 'Seller delivers', 'You inspect on arrival.'],
              ['3', 'Confirm delivery', 'Funds released. Auto-release after 7 days.'],
            ].map(([n, t, d]) => (
              <div key={n} style={{ display: 'flex', gap: 12 }}>
                <div style={{
                  width: 24, height: 24, borderRadius: 999, background: M_GREEN_50,
                  color: M_GREEN_700, fontFamily: 'JetBrains Mono, monospace', fontSize: 11,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700,
                  flexShrink: 0,
                }}>{n}</div>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{t}</div>
                  <div style={{ fontSize: 12, color: MUTED, marginTop: 2 }}>{d}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ marginTop: 22 }}>
          <Overline>PAYMENT METHOD</Overline>
          <div style={{
            marginTop: 10, padding: 14, border: `1px solid ${M_GREEN}`,
            borderRadius: 8, display: 'flex', alignItems: 'center', gap: 12,
            background: M_GREEN_50,
          }}>
            <Icon name="wallet" size={22} color={M_GREEN_700}/>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 600, fontSize: 14 }}>Bank transfer · ANB</div>
              <div style={{ fontSize: 12, color: MUTED }}>Ending 4421</div>
            </div>
            <Icon name="check" size={20} color={M_GREEN}/>
          </div>
        </div>
      </div>

      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0,
        padding: '12px 16px 28px', background: 'rgba(251,248,241,0.95)',
        backdropFilter: 'blur(12px)', borderTop: `1px solid ${HAIRLINE}`,
      }}>
        <Button full kind="primary" icon="arrowRight" onClick={()=>goTo('confirmed', l)}>Pay 14,400 SAR into escrow</Button>
      </div>
    </div>
  );
}

// Confirmation
function ConfirmedScreen({ listing, goTo }) {
  const l = listing || { title: 'Najdi ewes, 6 head', price: '14,400 SAR' };
  return (
    <div style={{ background: PAPER, minHeight: '100%', display: 'flex', flexDirection: 'column' }}>
      <AppBar title="" left={<button onClick={()=>goTo('home')} style={{background:'none',border:'none',padding:0,cursor:'pointer'}}><Icon name="chevronLeft" size={22}/></button>}/>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '0 24px' }}>
        <div style={{
          width: 72, height: 72, borderRadius: 999, background: M_GREEN,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          marginBottom: 28,
        }}>
          <Icon name="check" size={36} color={PAPER}/>
        </div>
        <div style={{
          fontFamily: 'Fraunces, serif', fontSize: 36, fontWeight: 400,
          letterSpacing: '-0.02em', lineHeight: 1.05,
        }}>Order placed.</div>
        <div style={{
          fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontSize: 22,
          color: M_GREEN_700, marginTop: 8,
        }}>Funds escrowed.</div>
        <div style={{ fontSize: 14, color: MUTED, marginTop: 16, lineHeight: 1.55, maxWidth: 320 }}>
          We're holding {l.price} until you confirm delivery. Yasir has been notified.
        </div>
        <div style={{
          marginTop: 28, padding: '14px 16px',
          background: PARCHMENT, border: `1px solid ${HAIRLINE}`, borderRadius: 8,
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12 }}>
            <span style={{ color: MUTED, fontFamily: 'JetBrains Mono, monospace', letterSpacing: '0.1em' }}>ORDER ID</span>
            <span style={{ fontFamily: 'JetBrains Mono, monospace', color: INK }}>ORD-2K7M-9F</span>
          </div>
        </div>
      </div>
      <div style={{ padding: '16px 16px 32px' }}>
        <Button full kind="primary" onClick={()=>goTo('home')}>Back to home</Button>
      </div>
    </div>
  );
}

// Profile screen
function ProfileScreen() {
  return (
    <div style={{ background: PARCHMENT, minHeight: '100%', paddingBottom: 96 }}>
      <AppBar title="Account"/>
      <div style={{ padding: 20, background: PAPER, borderBottom: `1px solid ${HAIRLINE}` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{
            width: 56, height: 56, borderRadius: 999, background: M_GREEN,
            color: PAPER, fontFamily: 'Fraunces, serif', fontSize: 24, fontWeight: 600,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>K</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: 'Fraunces, serif', fontSize: 20, fontWeight: 500 }}>Khalid Al-Mutairi</div>
            <div style={{ fontSize: 12, color: MUTED, marginTop: 3 }}>+966 5•• ••• 4221</div>
            <div style={{ marginTop: 6 }}><Chip kind="verified">KYC verified ✓</Chip></div>
          </div>
        </div>
      </div>
      <div style={{ marginTop: 16 }}>
        {[
          ['My listings', '4 active'],
          ['Orders', '2 in escrow'],
          ['Documents', 'KYC, halal certs'],
          ['Wallet', '12,400 SAR'],
          ['Language', 'English / العربية'],
          ['Help', null],
        ].map(([k, v], i, a) => (
          <div key={k} style={{
            padding: '14px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            background: PAPER, borderBottom: i < a.length - 1 ? `1px solid ${HAIRLINE}` : 'none',
          }}>
            <span style={{ fontSize: 15, fontWeight: 500 }}>{k}</span>
            <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              {v && <span style={{ fontSize: 12, color: MUTED }}>{v}</span>}
              <Icon name="chevronRight" size={16} color={MUTED}/>
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { HomeScreen, DetailScreen, ChatScreen, CheckoutScreen, ConfirmedScreen, ProfileScreen });
