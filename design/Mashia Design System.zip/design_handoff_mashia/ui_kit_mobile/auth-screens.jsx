// Mashia Mobile · Auth Screens
// Welcome → Sign-up (KYC) and Sign-in (phone + OTP)
// All consistent with the existing visual vocabulary (Fraunces display,
// Manrope body, JetBrains Mono overlines, Mashia green + parchment).

const { useState: useStateA } = React;

// ─────────────────────────────────────────────────────────────
// WELCOME — first-touch screen, choose Sign in / Create account
// ─────────────────────────────────────────────────────────────
function WelcomeScreen({ goTo }) {
  return (
    <div style={{
      minHeight: '100%', background: BASALT, color: PAPER,
      display: 'flex', flexDirection: 'column',
      backgroundImage: `radial-gradient(circle at 50% 18%, rgba(201,151,74,0.22), transparent 55%),
                        radial-gradient(circle at 50% 100%, rgba(0,115,57,0.45), transparent 60%)`,
    }}>
      {/* Top region — wordmark + tagline */}
      <div style={{ flex: 1, padding: '80px 28px 0', display: 'flex', flexDirection: 'column' }}>
        <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10,
                      letterSpacing: '0.22em', color: GOLD, textTransform: 'uppercase' }}>
          ● MASHIA · v1.0
        </div>

        <div style={{
          fontFamily: 'Fraunces, serif', fontSize: 64, fontWeight: 300,
          letterSpacing: '-0.035em', lineHeight: 0.95, marginTop: 28,
        }}>
          A green<br/>
          <em style={{ fontStyle: 'italic', color: GOLD, fontWeight: 400 }}>thread</em><br/>
          between<br/>
          markets.
        </div>

        <div style={{
          marginTop: 28, fontSize: 14, lineHeight: 1.55,
          color: SAND, maxWidth: 300,
        }}>
          Verified livestock trade across the Gulf and Levant.
          Escrow on every order. Halal certificates baked in.
        </div>
      </div>

      {/* Trust strip */}
      <div style={{
        margin: '0 24px 20px', padding: '14px 16px',
        background: 'rgba(255,255,255,0.06)', borderRadius: 8,
        border: '1px solid rgba(255,255,255,0.08)',
        display: 'flex', justifyContent: 'space-between',
      }}>
        {[
          ['KYC', 'verified'],
          ['Escrow', 'on every order'],
          ['Halal', 'certified'],
        ].map(([k, v]) => (
          <div key={k}>
            <div style={{ fontFamily: 'Fraunces, serif', fontSize: 18, fontWeight: 500, color: PAPER }}>{k}</div>
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9,
                          letterSpacing: '0.14em', textTransform: 'uppercase',
                          color: SAND, marginTop: 2 }}>{v}</div>
          </div>
        ))}
      </div>

      {/* Actions */}
      <div style={{ padding: '0 20px 32px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <button onClick={() => goTo('signup')} style={{
          background: M_GREEN, color: PAPER, border: 'none',
          padding: '16px', borderRadius: 8, fontFamily: 'Manrope, sans-serif',
          fontSize: 15, fontWeight: 600, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
        }}>
          Create account <Icon name="arrowRight" size={18} color={PAPER}/>
        </button>
        <button onClick={() => goTo('signin')} style={{
          background: 'transparent', color: PAPER,
          border: '1px solid rgba(255,255,255,0.25)',
          padding: '16px', borderRadius: 8, fontFamily: 'Manrope, sans-serif',
          fontSize: 15, fontWeight: 500, cursor: 'pointer',
        }}>
          I already have an account
        </button>

        <div style={{
          marginTop: 8, textAlign: 'center', fontSize: 11, color: SAND,
          lineHeight: 1.55,
        }}>
          By continuing you agree to Mashia&rsquo;s <span style={{ textDecoration: 'underline' }}>Terms</span>
          {' '}&amp; <span style={{ textDecoration: 'underline' }}>Privacy</span>.
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SIGN IN — phone number + OTP, two-step inline
// ─────────────────────────────────────────────────────────────
function SignInScreen({ goTo }) {
  const [step, setStep] = useStateA('phone'); // 'phone' | 'otp'
  const [phone, setPhone] = useStateA('5•• ••• 4221');
  const [otp, setOtp] = useStateA(['', '', '', '']);
  const [country, setCountry] = useStateA({ flag: '🇸🇦', code: '+966', name: 'KSA' });

  const countries = [
    { flag: '🇸🇦', code: '+966', name: 'KSA' },
    { flag: '🇦🇪', code: '+971', name: 'UAE' },
    { flag: '🇸🇾', code: '+963', name: 'SY' },
    { flag: '🇧🇭', code: '+973', name: 'BH' },
    { flag: '🇰🇼', code: '+965', name: 'KW' },
  ];
  const [pickerOpen, setPickerOpen] = useStateA(false);

  return (
    <div style={{ minHeight: '100%', background: PAPER, display: 'flex', flexDirection: 'column' }}>
      <AppBar
        title=""
        left={<button onClick={() => step === 'otp' ? setStep('phone') : goTo('welcome')}
                      style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}>
          <Icon name="chevronLeft" size={22}/>
        </button>}
      />

      {/* Step indicator */}
      <div style={{ padding: '4px 20px 0', display: 'flex', gap: 6 }}>
        <div style={{ height: 3, flex: 1, borderRadius: 2, background: M_GREEN }}/>
        <div style={{ height: 3, flex: 1, borderRadius: 2,
                      background: step === 'otp' ? M_GREEN : HAIRLINE }}/>
      </div>

      <div style={{ flex: 1, padding: '32px 24px 0' }}>
        <Overline>● {step === 'phone' ? '01 · YOUR NUMBER' : '02 · CONFIRM'}</Overline>
        <div style={{
          fontFamily: 'Fraunces, serif', fontSize: 36, fontWeight: 400,
          letterSpacing: '-0.025em', lineHeight: 1.05, marginTop: 14,
        }}>
          {step === 'phone'
            ? <>Welcome <em style={{ fontStyle: 'italic', color: M_GREEN_700 }}>back</em>.</>
            : <>Six digits<br/><em style={{ fontStyle: 'italic', color: M_GREEN_700 }}>to verify</em>.</>}
        </div>
        <div style={{ fontSize: 14, color: MUTED, marginTop: 12, lineHeight: 1.55, maxWidth: 320 }}>
          {step === 'phone'
            ? 'Sign in with your registered mobile number. We send a one-time code by SMS.'
            : <>We sent a code to <span style={{ color: INK, fontWeight: 600 }}>{country.code} {phone}</span>.</>}
        </div>

        {/* Step 1: phone field */}
        {step === 'phone' && (
          <div style={{ marginTop: 36 }}>
            <Overline>MOBILE NUMBER</Overline>
            <div style={{
              marginTop: 10, display: 'flex', gap: 8, alignItems: 'stretch',
            }}>
              <button onClick={() => setPickerOpen(p => !p)} style={{
                background: PARCHMENT, border: `1px solid ${HAIRLINE}`,
                borderRadius: 8, padding: '0 12px',
                display: 'flex', alignItems: 'center', gap: 8,
                cursor: 'pointer', fontFamily: 'Manrope, sans-serif',
              }}>
                <span style={{ fontSize: 20 }}>{country.flag}</span>
                <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 13, color: INK }}>
                  {country.code}
                </span>
                <Icon name="chevronRight" size={14} color={MUTED}/>
              </button>
              <input
                value={phone}
                onChange={e => setPhone(e.target.value)}
                style={{
                  flex: 1, background: PAPER, border: `1px solid ${M_GREEN}`,
                  borderRadius: 8, padding: '14px 14px',
                  fontFamily: 'Manrope, sans-serif', fontSize: 15, color: INK,
                  outline: 'none',
                }}
              />
            </div>

            {pickerOpen && (
              <div style={{
                marginTop: 8, background: PAPER, border: `1px solid ${HAIRLINE}`,
                borderRadius: 8, overflow: 'hidden',
              }}>
                {countries.map(c => (
                  <button key={c.code} onClick={() => { setCountry(c); setPickerOpen(false); }}
                          style={{
                            width: '100%', textAlign: 'left',
                            padding: '12px 14px', background: 'none', border: 'none',
                            borderBottom: `1px solid ${HAIRLINE}`, cursor: 'pointer',
                            display: 'flex', gap: 12, alignItems: 'center',
                            fontFamily: 'Manrope, sans-serif',
                          }}>
                    <span style={{ fontSize: 18 }}>{c.flag}</span>
                    <span style={{ flex: 1, fontSize: 14 }}>{c.name}</span>
                    <span style={{ fontFamily: 'JetBrains Mono, monospace',
                                   fontSize: 12, color: MUTED }}>{c.code}</span>
                  </button>
                ))}
              </div>
            )}

            <div style={{
              marginTop: 14, padding: '10px 12px', background: M_GREEN_50,
              borderRadius: 6, fontSize: 12, color: M_GREEN_700, lineHeight: 1.5,
              display: 'flex', gap: 8, alignItems: 'flex-start',
            }}>
              <Icon name="shield" size={14} color={M_GREEN}/>
              <span>Your number stays private. We never share it with sellers or buyers.</span>
            </div>
          </div>
        )}

        {/* Step 2: OTP */}
        {step === 'otp' && (
          <div style={{ marginTop: 36 }}>
            <Overline>6-DIGIT CODE</Overline>
            <div style={{ marginTop: 10, display: 'flex', gap: 8 }}>
              {[0,1,2,3,4,5].map(i => (
                <div key={i} style={{
                  flex: 1, aspectRatio: '1/1.1',
                  border: `1px solid ${i < 4 ? M_GREEN : HAIRLINE}`,
                  borderRadius: 8, background: i < 4 ? M_GREEN_50 : PAPER,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontFamily: 'Fraunces, serif', fontSize: 28, fontWeight: 500,
                  color: i < 4 ? M_GREEN_700 : MUTED,
                }}>
                  {i < 4 ? ['8','3','7','1'][i] : ''}
                </div>
              ))}
            </div>
            <div style={{
              marginTop: 14, display: 'flex', justifyContent: 'space-between',
              alignItems: 'center', fontSize: 13,
            }}>
              <span style={{ color: MUTED }}>Resend code in <span style={{
                fontFamily: 'JetBrains Mono, monospace', color: INK,
              }}>0:42</span></span>
              <button style={{ background: 'none', border: 'none', padding: 0,
                               color: M_GREEN_700, fontWeight: 600, cursor: 'pointer',
                               fontFamily: 'Manrope, sans-serif', fontSize: 13 }}>
                Call instead
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Sticky bottom action */}
      <div style={{
        padding: '16px 20px 32px', borderTop: `1px solid ${HAIRLINE}`,
        background: PAPER,
      }}>
        <Button full kind="primary" icon="arrowRight"
                onClick={() => step === 'phone' ? setStep('otp') : goTo('home')}>
          {step === 'phone' ? 'Send code' : 'Verify and continue'}
        </Button>
        {step === 'phone' && (
          <div style={{ marginTop: 14, textAlign: 'center', fontSize: 13, color: MUTED }}>
            Don&rsquo;t have an account?{' '}
            <button onClick={() => goTo('signup')} style={{
              background: 'none', border: 'none', padding: 0, cursor: 'pointer',
              color: M_GREEN_700, fontWeight: 600, fontFamily: 'Manrope, sans-serif',
              fontSize: 13,
            }}>Create one</button>
          </div>
        )}
        {step === 'otp' && (
          <div style={{ marginTop: 14, textAlign: 'center', fontSize: 13, color: MUTED }}>
            Can&rsquo;t access this number?{' '}
            <button onClick={() => goTo('recover')} style={{
              background: 'none', border: 'none', padding: 0, cursor: 'pointer',
              color: M_GREEN_700, fontWeight: 600, fontFamily: 'Manrope, sans-serif',
              fontSize: 13,
            }}>Recover access</button>
          </div>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SIGN UP — multi-step: role → identity → KYC documents
// ─────────────────────────────────────────────────────────────
function SignUpScreen({ goTo }) {
  const [step, setStep] = useStateA(1); // 1 = role, 2 = identity, 3 = KYC
  const [role, setRole] = useStateA('buyer'); // buyer | seller | broker
  const [name, setName] = useStateA('Khalid Al-Mutairi');
  const [region, setRegion] = useStateA('Riyadh');

  const next = () => step < 3 ? setStep(step + 1) : goTo('home');
  const back = () => step > 1 ? setStep(step - 1) : goTo('welcome');

  return (
    <div style={{ minHeight: '100%', background: PAPER, display: 'flex', flexDirection: 'column' }}>
      <AppBar
        title=""
        left={<button onClick={back} style={{ background: 'none', border: 'none',
                                              padding: 0, cursor: 'pointer' }}>
          <Icon name="chevronLeft" size={22}/>
        </button>}
        right={<span style={{
          fontFamily: 'JetBrains Mono, monospace', fontSize: 11,
          color: MUTED, letterSpacing: '0.1em',
        }}>{step} / 3</span>}
      />

      {/* Step indicator bars */}
      <div style={{ padding: '4px 20px 0', display: 'flex', gap: 6 }}>
        {[1,2,3].map(n => (
          <div key={n} style={{
            height: 3, flex: 1, borderRadius: 2,
            background: n <= step ? M_GREEN : HAIRLINE,
          }}/>
        ))}
      </div>

      <div style={{ flex: 1, padding: '32px 24px 0', overflow: 'auto' }}>
        {step === 1 && <SignUpStepRole role={role} setRole={setRole}/>}
        {step === 2 && <SignUpStepIdentity name={name} setName={setName} region={region} setRegion={setRegion}/>}
        {step === 3 && <SignUpStepKYC role={role}/>}
      </div>

      <div style={{
        padding: '16px 20px 32px', borderTop: `1px solid ${HAIRLINE}`,
        background: PAPER,
      }}>
        <Button full kind="primary" icon="arrowRight" onClick={next}>
          {step === 3 ? 'Submit for review' : 'Continue'}
        </Button>
        {step === 1 && (
          <div style={{ marginTop: 14, textAlign: 'center', fontSize: 13, color: MUTED }}>
            Already have an account?{' '}
            <button onClick={() => goTo('signin')} style={{
              background: 'none', border: 'none', padding: 0, cursor: 'pointer',
              color: M_GREEN_700, fontWeight: 600, fontFamily: 'Manrope, sans-serif',
              fontSize: 13,
            }}>Sign in</button>
          </div>
        )}
      </div>
    </div>
  );
}

function SignUpStepRole({ role, setRole }) {
  const opts = [
    { id: 'buyer', t: 'Buyer', d: 'Browse listings, place orders into escrow, receive deliveries.' },
    { id: 'seller', t: 'Seller', d: 'List your livestock, negotiate, deliver. Vet certs required.' },
    { id: 'broker', t: 'Broker', d: 'Connect buyers and sellers. Earn on verified deals.' },
  ];
  return (
    <>
      <Overline>● 01 · WHO ARE YOU</Overline>
      <div style={{
        fontFamily: 'Fraunces, serif', fontSize: 36, fontWeight: 400,
        letterSpacing: '-0.025em', lineHeight: 1.05, marginTop: 14,
      }}>
        Pick your <em style={{ fontStyle: 'italic', color: M_GREEN_700 }}>role</em>.
      </div>
      <div style={{ fontSize: 14, color: MUTED, marginTop: 10, lineHeight: 1.55, maxWidth: 320 }}>
        You can hold more than one. We&rsquo;ll set up your home screen accordingly.
      </div>

      <div style={{ marginTop: 28, display: 'flex', flexDirection: 'column', gap: 10 }}>
        {opts.map(o => {
          const sel = role === o.id;
          return (
            <button key={o.id} onClick={() => setRole(o.id)} style={{
              textAlign: 'left', cursor: 'pointer',
              background: sel ? M_GREEN_50 : PAPER,
              border: `1px solid ${sel ? M_GREEN : HAIRLINE}`,
              borderRadius: 8, padding: 16,
              display: 'flex', gap: 12, alignItems: 'flex-start',
              fontFamily: 'Manrope, sans-serif',
            }}>
              <div style={{
                width: 22, height: 22, borderRadius: 999, flexShrink: 0,
                border: `2px solid ${sel ? M_GREEN : HAIRLINE}`,
                background: sel ? M_GREEN : 'transparent',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                marginTop: 2,
              }}>
                {sel && <div style={{ width: 8, height: 8, borderRadius: 999, background: PAPER }}/>}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{
                  fontFamily: 'Fraunces, serif', fontSize: 18, fontWeight: 500,
                  color: sel ? M_GREEN_700 : INK,
                }}>{o.t}</div>
                <div style={{ fontSize: 13, color: MUTED, marginTop: 4, lineHeight: 1.5 }}>{o.d}</div>
              </div>
            </button>
          );
        })}
      </div>
    </>
  );
}

function SignUpStepIdentity({ name, setName, region, setRegion }) {
  const regions = ['Riyadh', 'Damascus', 'Dubai', 'Manama', 'Kuwait City', 'Doha'];
  return (
    <>
      <Overline>● 02 · YOUR IDENTITY</Overline>
      <div style={{
        fontFamily: 'Fraunces, serif', fontSize: 36, fontWeight: 400,
        letterSpacing: '-0.025em', lineHeight: 1.05, marginTop: 14,
      }}>
        Tell us your <em style={{ fontStyle: 'italic', color: M_GREEN_700 }}>name</em>.
      </div>
      <div style={{ fontSize: 14, color: MUTED, marginTop: 10, lineHeight: 1.55, maxWidth: 320 }}>
        Use your full legal name. It must match your national ID for KYC.
      </div>

      <div style={{ marginTop: 28 }}>
        <Overline>FULL NAME</Overline>
        <input
          value={name}
          onChange={e => setName(e.target.value)}
          style={{
            marginTop: 10, width: '100%', boxSizing: 'border-box',
            background: PAPER, border: `1px solid ${HAIRLINE}`,
            borderRadius: 8, padding: '14px',
            fontFamily: 'Manrope, sans-serif', fontSize: 15, color: INK,
            outline: 'none',
          }}
        />
      </div>

      <div style={{ marginTop: 22 }}>
        <Overline>REGION</Overline>
        <div style={{ marginTop: 10, display: 'flex', flexWrap: 'wrap', gap: 8 }}>
          {regions.map(r => (
            <button key={r} onClick={() => setRegion(r)} style={{
              background: region === r ? M_GREEN_50 : PAPER,
              border: `1px solid ${region === r ? M_GREEN : HAIRLINE}`,
              color: region === r ? M_GREEN_700 : INK,
              borderRadius: 999, padding: '8px 14px',
              fontFamily: 'Manrope, sans-serif', fontSize: 13, fontWeight: 500,
              cursor: 'pointer',
            }}>{r}</button>
          ))}
        </div>
      </div>

      <div style={{ marginTop: 22 }}>
        <Overline>LANGUAGE</Overline>
        <div style={{
          marginTop: 10, padding: 4, background: PARCHMENT,
          border: `1px solid ${HAIRLINE}`, borderRadius: 999,
          display: 'flex',
        }}>
          {['English', 'العربية'].map((l, i) => (
            <button key={l} style={{
              flex: 1, padding: '10px 12px', borderRadius: 999, border: 'none',
              background: i === 0 ? PAPER : 'transparent',
              color: i === 0 ? INK : MUTED, fontWeight: 500,
              boxShadow: i === 0 ? '0 1px 3px rgba(0,0,0,0.06)' : 'none',
              fontFamily: i === 1 ? 'Reem Kufi, sans-serif' : 'Manrope, sans-serif',
              fontSize: 14, cursor: 'pointer',
            }}>{l}</button>
          ))}
        </div>
      </div>
    </>
  );
}

function SignUpStepKYC({ role }) {
  const docs = role === 'seller'
    ? [
        { t: 'National ID', d: 'Front + back', state: 'done' },
        { t: 'Selfie with ID', d: 'For face match', state: 'done' },
        { t: 'Vet certificate', d: 'PDF · per breed', state: 'pending' },
        { t: 'Halal cert', d: 'Optional · boosts trust', state: 'idle' },
      ]
    : [
        { t: 'National ID', d: 'Front + back', state: 'done' },
        { t: 'Selfie with ID', d: 'For face match', state: 'pending' },
      ];
  return (
    <>
      <Overline>● 03 · VERIFY YOU</Overline>
      <div style={{
        fontFamily: 'Fraunces, serif', fontSize: 36, fontWeight: 400,
        letterSpacing: '-0.025em', lineHeight: 1.05, marginTop: 14,
      }}>
        KYC <em style={{ fontStyle: 'italic', color: M_GREEN_700 }}>documents</em>.
      </div>
      <div style={{ fontSize: 14, color: MUTED, marginTop: 10, lineHeight: 1.55, maxWidth: 320 }}>
        We review within 24 hours. Until then you can browse, but not transact.
      </div>

      <div style={{ marginTop: 28, display: 'flex', flexDirection: 'column', gap: 10 }}>
        {docs.map(d => {
          const tone = d.state === 'done' ? 'verified'
                       : d.state === 'pending' ? 'pending' : 'neutral';
          const bg = d.state === 'done' ? M_GREEN_50
                     : d.state === 'pending' ? '#FBF4E5' : PARCHMENT;
          const border = d.state === 'done' ? '#A4D6B8'
                         : d.state === 'pending' ? '#E5CC9B' : HAIRLINE;
          return (
            <div key={d.t} style={{
              padding: 14, background: bg, border: `1px solid ${border}`,
              borderRadius: 8, display: 'flex', alignItems: 'center', gap: 12,
            }}>
              <div style={{
                width: 40, height: 40, borderRadius: 8, flexShrink: 0,
                background: PAPER, border: `1px solid ${HAIRLINE}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <Icon name={d.state === 'done' ? 'check' : 'image'} size={18}
                      color={d.state === 'done' ? M_GREEN : MUTED}/>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 14 }}>{d.t}</div>
                <div style={{ fontSize: 12, color: MUTED, marginTop: 2 }}>{d.d}</div>
              </div>
              <Chip kind={tone}>
                {d.state === 'done' ? 'Uploaded ✓'
                 : d.state === 'pending' ? 'Uploading…' : 'Add'}
              </Chip>
            </div>
          );
        })}
      </div>

      <div style={{
        marginTop: 22, padding: 14, background: BASALT, color: PAPER,
        borderRadius: 8,
      }}>
        <Overline color={GOLD}>● WHY WE ASK</Overline>
        <div style={{ fontSize: 13, lineHeight: 1.55, color: SAND, marginTop: 8 }}>
          Mashia is a verified marketplace. Every trader is KYC&rsquo;d before they can buy or sell &mdash;
          that&rsquo;s how escrow stays trustworthy.
        </div>
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────
// RECOVER ACCESS — "I lost my phone number"
// 3-step KYC re-verification (no password reset; Mashia is OTP-only)
// ─────────────────────────────────────────────────────────────
function RecoverAccessScreen({ goTo }) {
  const [step, setStep] = useStateA(1); // 1 identity, 2 selfie, 3 new phone
  const [name, setName] = useStateA('Khalid Al-Mutairi');
  const [idNum, setIdNum] = useStateA('1•••••••821');
  const [newPhone, setNewPhone] = useStateA('5•• ••• 7732');

  const next = () => step < 3 ? setStep(step + 1) : setStep(4);
  const back = () => step === 1 ? goTo('signin') : setStep(step - 1);

  return (
    <div style={{ minHeight: '100%', background: PAPER, display: 'flex', flexDirection: 'column' }}>
      <AppBar
        title=""
        left={<button onClick={back} style={{ background: 'none', border: 'none',
                                              padding: 0, cursor: 'pointer' }}>
          <Icon name="chevronLeft" size={22}/>
        </button>}
        right={step <= 3 && <span style={{
          fontFamily: 'JetBrains Mono, monospace', fontSize: 11,
          color: MUTED, letterSpacing: '0.1em',
        }}>{step} / 3</span>}
      />

      {step <= 3 && (
        <div style={{ padding: '4px 20px 0', display: 'flex', gap: 6 }}>
          {[1,2,3].map(n => (
            <div key={n} style={{
              height: 3, flex: 1, borderRadius: 2,
              background: n <= step ? M_GREEN : HAIRLINE,
            }}/>
          ))}
        </div>
      )}

      <div style={{ flex: 1, padding: '32px 24px 0', overflow: 'auto' }}>
        {step === 1 && (
          <>
            <Overline>● 01 · CONFIRM IDENTITY</Overline>
            <div style={{
              fontFamily: 'Fraunces, serif', fontSize: 36, fontWeight: 400,
              letterSpacing: '-0.025em', lineHeight: 1.05, marginTop: 14,
            }}>
              Lost your <em style={{ fontStyle: 'italic', color: M_GREEN_700 }}>number</em>?
            </div>
            <div style={{ fontSize: 14, color: MUTED, marginTop: 10, lineHeight: 1.55, maxWidth: 320 }}>
              No password to reset &mdash; Mashia is OTP-only. Instead, we&rsquo;ll re-verify
              your KYC and move your account to a new number. Reviewed within 24 hours.
            </div>

            <div style={{ marginTop: 28 }}>
              <Overline>FULL NAME (AS ON ID)</Overline>
              <input
                value={name} onChange={e => setName(e.target.value)}
                style={{
                  marginTop: 10, width: '100%', boxSizing: 'border-box',
                  background: PAPER, border: `1px solid ${HAIRLINE}`,
                  borderRadius: 8, padding: 14,
                  fontFamily: 'Manrope, sans-serif', fontSize: 15,
                  color: INK, outline: 'none',
                }}
              />
            </div>

            <div style={{ marginTop: 18 }}>
              <Overline>NATIONAL ID NUMBER</Overline>
              <input
                value={idNum} onChange={e => setIdNum(e.target.value)}
                style={{
                  marginTop: 10, width: '100%', boxSizing: 'border-box',
                  background: PAPER, border: `1px solid ${HAIRLINE}`,
                  borderRadius: 8, padding: 14,
                  fontFamily: 'JetBrains Mono, monospace', fontSize: 15,
                  letterSpacing: '0.05em', color: INK, outline: 'none',
                }}
              />
            </div>

            <div style={{
              marginTop: 18, padding: '10px 12px', background: M_GREEN_50,
              borderRadius: 6, fontSize: 12, color: M_GREEN_700, lineHeight: 1.5,
              display: 'flex', gap: 8, alignItems: 'flex-start',
            }}>
              <Icon name="shield" size={14} color={M_GREEN}/>
              <span>Must match the ID on file. We hash and check &mdash; we don&rsquo;t display your full number anywhere.</span>
            </div>
          </>
        )}

        {step === 2 && (
          <>
            <Overline>● 02 · SELFIE WITH ID</Overline>
            <div style={{
              fontFamily: 'Fraunces, serif', fontSize: 36, fontWeight: 400,
              letterSpacing: '-0.025em', lineHeight: 1.05, marginTop: 14,
            }}>
              Show your <em style={{ fontStyle: 'italic', color: M_GREEN_700 }}>face</em>.
            </div>
            <div style={{ fontSize: 14, color: MUTED, marginTop: 10, lineHeight: 1.55, maxWidth: 320 }}>
              Hold your national ID next to your face. Plain background, good light.
              We compare it to the photo we have on file.
            </div>

            <div style={{
              marginTop: 28, aspectRatio: '4/5', borderRadius: 12, overflow: 'hidden',
              border: `1px solid ${HAIRLINE}`, position: 'relative',
              background: `linear-gradient(180deg, #2A2E2B 0%, #14181A 100%)`,
            }}>
              {/* simulated viewfinder */}
              <div style={{
                position: 'absolute', inset: 24, border: `2px dashed ${SAND}`,
                borderRadius: 12, opacity: 0.6,
              }}/>
              <div style={{
                position: 'absolute', top: '50%', left: '50%',
                transform: 'translate(-50%, -50%)',
                width: 120, height: 120, borderRadius: 999,
                border: `3px solid ${SAND}`, opacity: 0.5,
              }}/>
              <div style={{
                position: 'absolute', bottom: 18, left: 18, right: 18,
                fontFamily: 'JetBrains Mono, monospace', fontSize: 10,
                letterSpacing: '0.16em', textTransform: 'uppercase',
                color: SAND, textAlign: 'center',
              }}>
                ● live capture · face in circle, ID in hand
              </div>
            </div>

            <div style={{
              marginTop: 14, padding: '10px 12px', background: PARCHMENT,
              borderRadius: 6, fontSize: 12, color: MUTED, lineHeight: 1.5,
              display: 'flex', gap: 8, alignItems: 'flex-start',
            }}>
              <Icon name="image" size={14} color={MUTED}/>
              <span>Liveness check &mdash; you may be asked to blink or turn your head.</span>
            </div>
          </>
        )}

        {step === 3 && (
          <>
            <Overline>● 03 · NEW NUMBER</Overline>
            <div style={{
              fontFamily: 'Fraunces, serif', fontSize: 36, fontWeight: 400,
              letterSpacing: '-0.025em', lineHeight: 1.05, marginTop: 14,
            }}>
              Where shall we<br/>
              <em style={{ fontStyle: 'italic', color: M_GREEN_700 }}>reach you</em> now?
            </div>
            <div style={{ fontSize: 14, color: MUTED, marginTop: 10, lineHeight: 1.55, maxWidth: 320 }}>
              We&rsquo;ll move your account, listings, escrow balance and order history to
              this number once review passes.
            </div>

            <div style={{ marginTop: 28 }}>
              <Overline>NEW MOBILE NUMBER</Overline>
              <div style={{ marginTop: 10, display: 'flex', gap: 8 }}>
                <div style={{
                  background: PARCHMENT, border: `1px solid ${HAIRLINE}`,
                  borderRadius: 8, padding: '0 12px',
                  display: 'flex', alignItems: 'center', gap: 8,
                  fontFamily: 'Manrope, sans-serif',
                }}>
                  <span style={{ fontSize: 20 }}>🇸🇦</span>
                  <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 13, color: INK }}>+966</span>
                </div>
                <input
                  value={newPhone} onChange={e => setNewPhone(e.target.value)}
                  style={{
                    flex: 1, background: PAPER, border: `1px solid ${M_GREEN}`,
                    borderRadius: 8, padding: 14,
                    fontFamily: 'Manrope, sans-serif', fontSize: 15,
                    color: INK, outline: 'none',
                  }}
                />
              </div>
            </div>

            <div style={{
              marginTop: 22, padding: 14, background: BASALT, color: PAPER,
              borderRadius: 8,
            }}>
              <Overline color={GOLD}>● WHAT HAPPENS NEXT</Overline>
              <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 10 }}>
                {[
                  ['1', 'Mashia ops review', 'Manual KYC re-check, within 24h.'],
                  ['2', 'Old number locked', 'Cannot sign in from old number once approved.'],
                  ['3', 'OTP to new number', 'Sign in with the new number going forward.'],
                ].map(([n, t, d]) => (
                  <div key={n} style={{ display: 'flex', gap: 12 }}>
                    <div style={{
                      width: 22, height: 22, borderRadius: 999, background: GOLD,
                      color: BASALT, fontFamily: 'JetBrains Mono, monospace',
                      fontSize: 11, fontWeight: 700, flexShrink: 0,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}>{n}</div>
                    <div>
                      <div style={{ fontWeight: 600, fontSize: 13, color: PAPER }}>{t}</div>
                      <div style={{ fontSize: 12, color: SAND, marginTop: 2, lineHeight: 1.5 }}>{d}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {step === 4 && (
          <div style={{
            display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
            justifyContent: 'center', minHeight: '100%', paddingBottom: 40,
          }}>
            <div style={{
              width: 64, height: 64, borderRadius: 999, background: M_GREEN_50,
              border: `1px solid #A4D6B8`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              marginBottom: 24,
            }}>
              <Icon name="shield" size={28} color={M_GREEN}/>
            </div>
            <Overline color={M_GREEN_700}>● SUBMITTED</Overline>
            <div style={{
              fontFamily: 'Fraunces, serif', fontSize: 36, fontWeight: 400,
              letterSpacing: '-0.025em', lineHeight: 1.05, marginTop: 14,
            }}>
              Under <em style={{ fontStyle: 'italic', color: M_GREEN_700 }}>review</em>.
            </div>
            <div style={{ fontSize: 14, color: MUTED, marginTop: 12, lineHeight: 1.55, maxWidth: 320 }}>
              We&rsquo;re re-verifying your KYC. You&rsquo;ll get an SMS at <span style={{
                color: INK, fontWeight: 600,
              }}>+966 {newPhone}</span> within 24 hours. Browse continues to work; transactions are paused until approval.
            </div>

            <div style={{
              marginTop: 24, alignSelf: 'stretch', padding: '12px 14px',
              background: PARCHMENT, border: `1px solid ${HAIRLINE}`, borderRadius: 8,
              display: 'flex', justifyContent: 'space-between', fontSize: 12,
            }}>
              <span style={{ color: MUTED, fontFamily: 'JetBrains Mono, monospace', letterSpacing: '0.1em' }}>CASE ID</span>
              <span style={{ fontFamily: 'JetBrains Mono, monospace', color: INK }}>REC-9F2K-7M</span>
            </div>
          </div>
        )}
      </div>

      <div style={{
        padding: '16px 20px 32px', borderTop: `1px solid ${HAIRLINE}`, background: PAPER,
      }}>
        {step <= 3 ? (
          <Button full kind="primary" icon="arrowRight" onClick={next}>
            {step === 3 ? 'Submit for review' : 'Continue'}
          </Button>
        ) : (
          <Button full kind="primary" onClick={() => goTo('welcome')}>Done</Button>
        )}
        {step === 1 && (
          <div style={{ marginTop: 14, textAlign: 'center', fontSize: 13, color: MUTED }}>
            Got it back?{' '}
            <button onClick={() => goTo('signin')} style={{
              background: 'none', border: 'none', padding: 0, cursor: 'pointer',
              color: M_GREEN_700, fontWeight: 600, fontFamily: 'Manrope, sans-serif',
              fontSize: 13,
            }}>Sign in normally</button>
          </div>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { WelcomeScreen, SignInScreen, SignUpScreen, RecoverAccessScreen });
