# Mashia Mobile UI Kit

React Native trader app — recreated as React + JSX for design fidelity. Ten screens spanning the full trader journey: welcome → sign-in / sign-up (3-step KYC) → recover-access (KYC re-verification, no password reset) → home → listing → chat → escrow → confirmed, plus account.

## Files
- `components.jsx` — atomic UI: `Icon`, `Chip`, `Button`, `ListingCard`, `BottomNav`, `AppBar`, `SearchField`, `SectionHeader`, `Overline`, `ListingImage`. Color constants exported on window.
- `screens.jsx` — `HomeScreen`, `DetailScreen`, `ChatScreen`, `CheckoutScreen`, `ConfirmedScreen`, `ProfileScreen`. Each takes a `goTo(name, payload?)` prop.
- `auth-screens.jsx` — `WelcomeScreen`, `SignInScreen` (phone + OTP, two-step), `SignUpScreen` (3-step: role → identity → KYC documents), `RecoverAccessScreen` (4-step KYC re-verification for lost phone numbers).
- `ios-frame.jsx` — iPhone bezel + status bar.
- `index.html` — interactive prototype: 10 phones side-by-side, click through any of them.

## Notes
This kit was designed against the brand guide; **no React Native codebase was provided**. Visuals should still translate cleanly to RN (Stylesheet objects, Image, FlatList, etc.) — types and color tokens match the brand guide. Replace placeholder `ListingImage` gradients with real photography when available.

## Status / TODOs
- Real animal photography
- Seller-side flows (create listing, manage orders)
- RTL (Arabic) variant — components are RTL-safe but the prototype renders LTR
