# Mashia Admin UI Kit

Next.js admin dashboard — recreated as React + JSX for design fidelity. Four main screens: dashboard, listings table, KYC review, moderation queue.

## Files
- `components.jsx` — `Sidebar`, `TopBar`, `StatCard`, `Table`, `AButton`, `ABadge`, `AOverline`, `AIcon`. (Prefixed `A` to avoid colliding with the mobile kit when both are loaded.)
- `screens.jsx` — `Dashboard`, `ListingsScreen`, `KycScreen`, `ModerationScreen`.
- `index.html` — full-page interactive prototype with working sidebar navigation.

## Notes
- No Next.js codebase was provided, so this kit is designed against the brand guide + product description. Tables, KYC review, and moderation queues match the marketplace domain (escrow, halal/vet certs, KYC).
- The dashboard chart is a static SVG sparkline — swap for a real chart library (Recharts, Visx) in production.

## TODOs
- Order detail / escrow release flow
- Settings & roles
- Audit log
- Real charts
