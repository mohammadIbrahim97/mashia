// Mashia Admin · Screens
const { useState: useStateAS } = React;

function Dashboard() {
  return (
    <div style={{ padding: 32, background: A_PARCHMENT, minHeight: '100%' }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
        <StatCard label="GMV · LAST 30D" value="2.4M SAR" delta="+18%" deltaPositive hint="vs prev 30d" />
        <StatCard label="ORDERS IN ESCROW" value="142" delta="+12" deltaPositive hint="this week" />
        <StatCard label="KYC PENDING" value="12" delta="+3" hint="needs review" />
        <StatCard label="FLAGGED LISTINGS" value="4" delta="-2" deltaPositive hint="last 24h" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 16, marginTop: 24 }}>
        <div style={{ background: A_PAPER, border: `1px solid ${A_HAIRLINE}`, padding: 20, borderRadius: 6 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 16 }}>
            <div>
              <AOverline>● GMV TREND</AOverline>
              <div style={{ fontFamily: 'Fraunces, serif', fontSize: 20, fontWeight: 500, marginTop: 4 }}>Last 30 days</div>
            </div>
            <ABadge kind="verified">Live</ABadge>
          </div>
          <svg viewBox="0 0 600 180" width="100%" height="180" preserveAspectRatio="none">
            <defs>
              <linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#007339" stopOpacity="0.18"/>
                <stop offset="100%" stopColor="#007339" stopOpacity="0"/>
              </linearGradient>
            </defs>
            <path d="M0,140 L40,120 L80,128 L120,100 L160,108 L200,82 L240,90 L280,70 L320,76 L360,52 L400,60 L440,40 L480,48 L520,30 L560,38 L600,18 L600,180 L0,180 Z" fill="url(#g)"/>
            <path d="M0,140 L40,120 L80,128 L120,100 L160,108 L200,82 L240,90 L280,70 L320,76 L360,52 L400,60 L440,40 L480,48 L520,30 L560,38 L600,18" fill="none" stroke="#007339" strokeWidth="2"/>
          </svg>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: A_MUTED, marginTop: 4 }}>
            <span>Apr 04</span><span>Apr 18</span><span>May 02</span>
          </div>
        </div>
        <div style={{ background: A_PAPER, border: `1px solid ${A_HAIRLINE}`, padding: 20, borderRadius: 6 }}>
          <AOverline>BY REGION</AOverline>
          <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
            {[['Riyadh', 42, A_GREEN], ['Damascus', 28, '#5C9856'], ['Dubai', 18, A_GOLD], ['Manama', 12, '#1F5F8F']].map(([n, p, c]) => (
              <div key={n}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 4 }}>
                  <span>{n}</span><span style={{ fontFamily: 'JetBrains Mono, monospace', color: A_MUTED }}>{p}%</span>
                </div>
                <div style={{ height: 6, background: A_PARCHMENT, borderRadius: 999, overflow: 'hidden' }}>
                  <div style={{ width: p + '%', height: '100%', background: c }}/>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div style={{ marginTop: 24 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
          <div style={{ fontFamily: 'Fraunces, serif', fontSize: 20, fontWeight: 500 }}>Recent orders</div>
          <AButton kind="ghost" sm>View all →</AButton>
        </div>
        <Table
          columns={[
            { key: 'id', label: 'Order', w: '140px', render: r => <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 12 }}>{r.id}</span> },
            { key: 'item', label: 'Listing' },
            { key: 'buyer', label: 'Buyer', w: '160px' },
            { key: 'amount', label: 'Amount', w: '130px', render: r => <span style={{ fontFamily: 'Fraunces, serif', fontWeight: 600, color: A_GREEN_700 }}>{r.amount}</span> },
            { key: 'status', label: 'Status', w: '140px', render: r => <ABadge kind={r.statusKind}>{r.status}</ABadge> },
          ]}
          rows={[
            { id: 'ORD-2K7M-9F', item: 'Najdi ewes, 6 head', buyer: 'K. Al-Mutairi', amount: '14,400 SAR', status: 'In escrow', statusKind: 'pending' },
            { id: 'ORD-2K7L-3A', item: 'Awassi rams, 12 head', buyer: 'M. Haddad', amount: '8,800 USD', status: 'Released', statusKind: 'verified' },
            { id: 'ORD-2K7K-1B', item: 'Harri lambs, 4 head', buyer: 'A. Bin Saeed', amount: '4,200 AED', status: 'In escrow', statusKind: 'pending' },
            { id: 'ORD-2K7J-7C', item: 'Sawakni breeding', buyer: 'F. Al-Khalifa', amount: '6,400 BHD', status: 'Flagged', statusKind: 'flagged' },
          ]}
        />
      </div>
    </div>
  );
}

function ListingsScreen() {
  return (
    <div style={{ padding: 32, background: A_PARCHMENT, minHeight: '100%' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <div style={{ display: 'flex', gap: 8 }}>
          <ABadge kind="verified">All · 1,284</ABadge>
          <ABadge kind="pending">Pending · 38</ABadge>
          <ABadge kind="flagged">Flagged · 4</ABadge>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <AButton kind="secondary" sm>Export CSV</AButton>
          <AButton sm>+ New listing</AButton>
        </div>
      </div>
      <Table
        columns={[
          { key: 'id', label: 'ID', w: '110px', render: r => <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 12 }}>{r.id}</span> },
          { key: 'title', label: 'Listing' },
          { key: 'seller', label: 'Seller', w: '160px' },
          { key: 'price', label: 'Price', w: '130px', render: r => <span style={{ fontFamily: 'Fraunces, serif', fontWeight: 600 }}>{r.price}</span> },
          { key: 'cert', label: 'Certs', w: '130px', render: r => <div style={{ display: 'flex', gap: 4 }}>{r.cert.map(c => <ABadge key={c} kind="verified">{c}</ABadge>)}</div> },
          { key: 'status', label: 'Status', w: '120px', render: r => <ABadge kind={r.statusKind}>{r.status}</ABadge> },
        ]}
        rows={[
          { id: 'SHP-RY-014', title: 'Najdi ewes, 6 head', seller: 'Y. Al-Otaibi', price: '14,400 SAR', cert: ['Vet', 'Halal'], status: 'Live', statusKind: 'verified' },
          { id: 'SHP-DM-027', title: 'Awassi rams, 12 head', seller: 'T. Haddad', price: '8,800 USD', cert: ['Vet', 'Halal'], status: 'Live', statusKind: 'verified' },
          { id: 'SHP-DX-009', title: 'Harri lambs, 4 head', seller: 'A. Bin Saeed', price: '4,200 AED', cert: ['Vet'], status: 'Pending', statusKind: 'pending' },
          { id: 'SHP-MN-002', title: 'Sawakni breeding', seller: 'F. Al-Khalifa', price: '6,400 BHD', cert: ['Vet'], status: 'Flagged', statusKind: 'flagged' },
          { id: 'SHP-RY-013', title: 'Najdi rams, 3 head', seller: 'S. Al-Qahtani', price: '7,200 SAR', cert: ['Vet', 'Halal'], status: 'Live', statusKind: 'verified' },
        ]}
      />
    </div>
  );
}

function KycScreen() {
  return (
    <div style={{ padding: 32, background: A_PARCHMENT, minHeight: '100%' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: 16 }}>
        <div>
          <AOverline>● PENDING REVIEW · 12</AOverline>
          <div style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[
              { name: 'Khalid Al-Mutairi', loc: 'Riyadh, SA', sub: '2h ago', sel: true },
              { name: 'Tarek Haddad', loc: 'Damascus, SY', sub: '4h ago' },
              { name: 'Aisha Bin Saeed', loc: 'Dubai, AE', sub: '6h ago' },
              { name: 'Fawzi Al-Khalifa', loc: 'Manama, BH', sub: '1d ago' },
            ].map(p => (
              <div key={p.name} style={{ background: A_PAPER, border: `1px solid ${p.sel ? A_GREEN : A_HAIRLINE}`, padding: 14, borderRadius: 6, display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer' }}>
                <div style={{ width: 36, height: 36, borderRadius: 999, background: A_GREEN_50, color: A_GREEN_700, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Fraunces, serif', fontWeight: 600 }}>{p.name[0]}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{p.name}</div>
                  <div style={{ fontSize: 12, color: A_MUTED }}>{p.loc} · {p.sub}</div>
                </div>
                <ABadge kind="pending">Pending</ABadge>
              </div>
            ))}
          </div>
        </div>

        <div style={{ background: A_PAPER, border: `1px solid ${A_HAIRLINE}`, borderRadius: 6, padding: 20, position: 'sticky', top: 0, alignSelf: 'start' }}>
          <AOverline>● REVIEWING</AOverline>
          <div style={{ fontFamily: 'Fraunces, serif', fontSize: 22, fontWeight: 500, marginTop: 6 }}>Khalid Al-Mutairi</div>
          <div style={{ fontSize: 12, color: A_MUTED }}>+966 5•• ••• 4221 · Riyadh</div>

          <div style={{ marginTop: 20, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            <div style={{ aspectRatio: '3/2', background: A_PARCHMENT, border: `1px solid ${A_HAIRLINE}`, borderRadius: 4, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <AIcon name="fileText" size={28} color={A_MUTED}/>
            </div>
            <div style={{ aspectRatio: '3/2', background: A_PARCHMENT, border: `1px solid ${A_HAIRLINE}`, borderRadius: 4, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <AIcon name="fileText" size={28} color={A_MUTED}/>
            </div>
          </div>
          <div style={{ fontSize: 11, color: A_MUTED, fontFamily: 'JetBrains Mono, monospace', letterSpacing: '0.1em', marginTop: 6 }}>NATIONAL ID · FRONT / BACK</div>

          <div style={{ marginTop: 20, paddingTop: 16, borderTop: `1px solid ${A_HAIRLINE}` }}>
            {[['ID type', 'Saudi National ID'], ['ID number', '1•••••• 4221'], ['DOB', '1989-03-12'], ['Selfie match', '98.4%']].map(([k,v]) => (
              <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', fontSize: 13 }}>
                <span style={{ color: A_MUTED }}>{k}</span>
                <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 12 }}>{v}</span>
              </div>
            ))}
          </div>

          <div style={{ display: 'flex', gap: 8, marginTop: 20 }}>
            <AButton kind="danger">Reject</AButton>
            <div style={{ flex: 1 }}/>
            <AButton kind="secondary">Request more</AButton>
            <AButton>Approve</AButton>
          </div>
        </div>
      </div>
    </div>
  );
}

function ModerationScreen() {
  return (
    <div style={{ padding: 32, background: A_PARCHMENT, minHeight: '100%' }}>
      <AOverline>● FLAGGED · 4</AOverline>
      <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 12 }}>
        {[
          { id: 'SHP-MN-002', title: 'Sawakni breeding', reason: 'Missing halal certificate', who: 'auto', when: '2h ago' },
          { id: 'SHP-RY-009', title: 'Najdi rams, 5 head', reason: 'Suspected duplicate listing', who: 'user report ×3', when: '5h ago' },
          { id: 'SHP-DM-018', title: 'Awassi ewes', reason: 'Vet cert expired (2024-11)', who: 'auto', when: '1d ago' },
          { id: 'SHP-DX-022', title: 'Harri lambs, 8 head', reason: 'Price 60% below market', who: 'auto', when: '2d ago' },
        ].map(f => (
          <div key={f.id} style={{ background: A_PAPER, border: `1px solid ${A_HAIRLINE}`, borderLeft: `3px solid #B23B3B`, borderRadius: 6, padding: 18, display: 'grid', gridTemplateColumns: '110px 1fr auto', gap: 18, alignItems: 'center' }}>
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 12 }}>{f.id}</div>
            <div>
              <div style={{ fontFamily: 'Fraunces, serif', fontSize: 16, fontWeight: 500 }}>{f.title}</div>
              <div style={{ fontSize: 13, color: '#8A2828', marginTop: 4 }}>{f.reason}</div>
              <div style={{ fontSize: 11, color: A_MUTED, marginTop: 4, fontFamily: 'JetBrains Mono, monospace' }}>{f.who.toUpperCase()} · {f.when}</div>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <AButton kind="secondary" sm>Dismiss</AButton>
              <AButton kind="danger" sm>Take down</AButton>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { Dashboard, ListingsScreen, KycScreen, ModerationScreen });
