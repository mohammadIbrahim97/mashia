// Mashia Admin · Atomic UI components
const { useState: useStateA } = React;

const A_GREEN = '#007339';
const A_GREEN_700 = '#005C2E';
const A_GREEN_50 = '#ECF7F0';
const A_PAPER = '#FBF8F1';
const A_PARCHMENT = '#F6F1E7';
const A_INK = '#14181A';
const A_MUTED = '#6B6E66';
const A_HAIRLINE = 'rgba(20,24,26,0.12)';
const A_GOLD = '#C9974A';
const A_BASALT = '#1A1E1B';

function AIcon({ name, size = 18, color }) {
  const props = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: color || 'currentColor', strokeWidth: 1.5, strokeLinecap: 'round', strokeLinejoin: 'round' };
  const paths = {
    dashboard: <><rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/></>,
    listings: <><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></>,
    users: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></>,
    orders: <><path d="M3 6h18l-2 13H5z"/><path d="M16 10a4 4 0 0 1-8 0"/></>,
    flag: <><line x1="4" y1="22" x2="4" y2="3"/><path d="M4 4h13l-2 5 2 5H4"/></>,
    shield: <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>,
    settings: <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.8-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.8 1.6 1.6 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3h.1a1.6 1.6 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8v.1a1.6 1.6 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z"/></>,
    search: <><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></>,
    bell: <><path d="M6 8a6 6 0 1 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10 21a2 2 0 0 0 4 0"/></>,
    check: <path d="M20 6 9 17l-5-5"/>,
    x: <><path d="M18 6 6 18M6 6l12 12"/></>,
    arrowUp: <polyline points="18 15 12 9 6 15"/>,
    arrowDown: <polyline points="6 9 12 15 18 9"/>,
    fileText: <><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></>,
    eye: <><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></>,
  };
  return <svg {...props}>{paths[name]}</svg>;
}

function ABadge({ kind = 'neutral', children }) {
  const styles = {
    verified: { bg: A_GREEN_50, fg: A_GREEN_700, border: '#A4D6B8' },
    pending: { bg: '#FBF1DD', fg: '#8A6418', border: '#E8CB8E' },
    flagged: { bg: '#F8E5E5', fg: '#8A2828', border: '#EBC0C0' },
    info: { bg: '#E5EEF5', fg: '#1F5F8F', border: '#BDD2E2' },
    neutral: { bg: A_PAPER, fg: A_INK, border: A_HAIRLINE },
  }[kind];
  return <span style={{ display: 'inline-flex', padding: '2px 8px', borderRadius: 999, fontFamily: 'Manrope', fontWeight: 600, fontSize: 11, background: styles.bg, color: styles.fg, border: `1px solid ${styles.border}` }}>{children}</span>;
}

function AOverline({ children, color }) {
  return <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, letterSpacing: '0.16em', textTransform: 'uppercase', color: color || A_MUTED }}>{children}</div>;
}

function AButton({ kind = 'primary', children, onClick, sm }) {
  const styles = {
    primary: { bg: A_GREEN, fg: A_PAPER, border: 'transparent' },
    secondary: { bg: 'transparent', fg: A_INK, border: A_INK },
    ghost: { bg: 'transparent', fg: A_GREEN, border: 'transparent' },
    danger: { bg: '#B23B3B', fg: A_PAPER, border: 'transparent' },
  }[kind];
  return <button onClick={onClick} style={{ padding: sm ? '6px 12px' : '10px 18px', fontFamily: 'Manrope', fontWeight: 600, fontSize: sm ? 12 : 13, background: styles.bg, color: styles.fg, border: `1px solid ${styles.border}`, cursor: 'pointer', borderRadius: 6 }}>{children}</button>;
}

// Sidebar
function Sidebar({ active, onChange }) {
  const items = [
    { id: 'dashboard', icon: 'dashboard', label: 'Dashboard' },
    { id: 'listings', icon: 'listings', label: 'Listings' },
    { id: 'orders', icon: 'orders', label: 'Orders' },
    { id: 'kyc', icon: 'shield', label: 'KYC queue', badge: 12 },
    { id: 'mod', icon: 'flag', label: 'Moderation', badge: 4 },
    { id: 'users', icon: 'users', label: 'Users' },
    { id: 'settings', icon: 'settings', label: 'Settings' },
  ];
  return (
    <aside style={{ width: 240, background: A_BASALT, color: '#DECDA6', height: '100%', display: 'flex', flexDirection: 'column', padding: '20px 0' }}>
      <div style={{ padding: '0 20px 24px', borderBottom: '1px solid rgba(222,205,166,0.15)' }}>
        <div style={{ fontFamily: 'Fraunces, serif', fontSize: 24, fontWeight: 300, letterSpacing: '-0.02em', color: A_PAPER }}>
          Mash<em style={{ fontStyle: 'italic', color: A_GOLD, fontFamily: 'Fraunces' }}>ia</em>
        </div>
        <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9, letterSpacing: '0.2em', textTransform: 'uppercase', marginTop: 6, opacity: 0.7 }}>● ADMIN · me-south-1</div>
      </div>
      <nav style={{ padding: '16px 12px', display: 'flex', flexDirection: 'column', gap: 2, flex: 1 }}>
        {items.map(it => {
          const sel = it.id === active;
          return (
            <button key={it.id} onClick={() => onChange(it.id)} style={{
              display: 'flex', alignItems: 'center', gap: 12, padding: '9px 12px',
              background: sel ? 'rgba(255,255,255,0.06)' : 'transparent',
              border: 'none', cursor: 'pointer', borderRadius: 6,
              color: sel ? A_PAPER : '#DECDA6', textAlign: 'left',
              borderLeft: sel ? `2px solid ${A_GOLD}` : '2px solid transparent',
            }}>
              <AIcon name={it.icon} size={18} color={sel ? A_GOLD : '#DECDA6'} />
              <span style={{ flex: 1, fontFamily: 'Manrope', fontSize: 13, fontWeight: sel ? 600 : 400 }}>{it.label}</span>
              {it.badge && <span style={{ background: A_GOLD, color: A_BASALT, fontFamily: 'JetBrains Mono, monospace', fontSize: 10, fontWeight: 700, padding: '1px 6px', borderRadius: 999 }}>{it.badge}</span>}
            </button>
          );
        })}
      </nav>
      <div style={{ padding: '16px 20px', borderTop: '1px solid rgba(222,205,166,0.15)', fontFamily: 'JetBrains Mono, monospace', fontSize: 10, letterSpacing: '0.1em', opacity: 0.6 }}>v1.0 · 2026</div>
    </aside>
  );
}

// Top bar
function TopBar({ title, breadcrumb }) {
  return (
    <header style={{ height: 64, padding: '0 32px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: `1px solid ${A_HAIRLINE}`, background: A_PAPER }}>
      <div>
        {breadcrumb && <AOverline>{breadcrumb}</AOverline>}
        <div style={{ fontFamily: 'Fraunces, serif', fontSize: 22, fontWeight: 500, letterSpacing: '-0.01em', marginTop: breadcrumb ? 2 : 0 }}>{title}</div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', background: A_PARCHMENT, border: `1px solid ${A_HAIRLINE}`, borderRadius: 6, width: 280 }}>
          <AIcon name="search" size={16} color={A_MUTED} />
          <input placeholder="Search orders, users…" style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', fontFamily: 'Manrope', fontSize: 13 }} />
          <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: A_MUTED, padding: '2px 5px', background: A_PAPER, border: `1px solid ${A_HAIRLINE}`, borderRadius: 3 }}>⌘K</span>
        </div>
        <AIcon name="bell" size={20} color={A_INK} />
        <div style={{ width: 32, height: 32, borderRadius: 999, background: A_GREEN, color: A_PAPER, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Fraunces, serif', fontWeight: 600, fontSize: 14 }}>L</div>
      </div>
    </header>
  );
}

// Stat card
function StatCard({ label, value, delta, deltaPositive, hint }) {
  return (
    <div style={{ background: A_PAPER, border: `1px solid ${A_HAIRLINE}`, padding: 20, borderRadius: 6 }}>
      <AOverline>{label}</AOverline>
      <div style={{ fontFamily: 'Fraunces, serif', fontSize: 36, fontWeight: 500, letterSpacing: '-0.02em', marginTop: 10, lineHeight: 1 }}>{value}</div>
      {delta && (
        <div style={{ marginTop: 8, display: 'flex', alignItems: 'center', gap: 4, fontSize: 12, color: deltaPositive ? A_GREEN_700 : '#8A2828' }}>
          <AIcon name={deltaPositive ? 'arrowUp' : 'arrowDown'} size={12} />
          <span style={{ fontWeight: 600 }}>{delta}</span>
          {hint && <span style={{ color: A_MUTED, fontWeight: 400, marginLeft: 4 }}>{hint}</span>}
        </div>
      )}
    </div>
  );
}

// Table
function Table({ columns, rows, onRowClick }) {
  return (
    <div style={{ background: A_PAPER, border: `1px solid ${A_HAIRLINE}`, borderRadius: 6, overflow: 'hidden' }}>
      <div style={{ display: 'grid', gridTemplateColumns: columns.map(c => c.w || '1fr').join(' '), padding: '12px 20px', borderBottom: `1px solid ${A_HAIRLINE}`, background: A_PARCHMENT }}>
        {columns.map(c => <div key={c.key} style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, letterSpacing: '0.14em', textTransform: 'uppercase', color: A_MUTED, fontWeight: 600 }}>{c.label}</div>)}
      </div>
      {rows.map((r, i) => (
        <div key={i} onClick={() => onRowClick && onRowClick(r)} style={{ display: 'grid', gridTemplateColumns: columns.map(c => c.w || '1fr').join(' '), padding: '14px 20px', borderBottom: i < rows.length - 1 ? `1px solid ${A_HAIRLINE}` : 'none', cursor: onRowClick ? 'pointer' : 'default', alignItems: 'center', fontSize: 13 }}>
          {columns.map(c => <div key={c.key}>{c.render ? c.render(r) : r[c.key]}</div>)}
        </div>
      ))}
    </div>
  );
}

Object.assign(window, { AIcon, ABadge, AOverline, AButton, Sidebar, TopBar, StatCard, Table, A_GREEN, A_GREEN_700, A_GREEN_50, A_PAPER, A_PARCHMENT, A_INK, A_MUTED, A_HAIRLINE, A_GOLD, A_BASALT });
