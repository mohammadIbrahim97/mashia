---
name: mashia-design
description: Use this skill to generate well-branded interfaces and assets for Mashia, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping the Mashia regional sheep-livestock marketplace (Gulf + Levant).
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files (`colors_and_type.css`, `assets/`, `preview/`, `ui_kits/mobile/`, `ui_kits/admin/`, `uploads/mashia-brand-guide.html`).

Mashia is a regional sheep-livestock marketplace connecting verified sellers, buyers, and brokers across the Gulf and Levant. Its visual language is editorial-modern: a single brand green (`#007339`, the bridge between Syrian and Saudi flag green), six heritage accents drawn from Syrian terrain, square corners, generous whitespace, and a Fraunces+Manrope (Latin) / Reem Kufi+Tajawal (Arabic) type pair. Bilingual is first-class; emoji are not used.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. Pull tokens from `colors_and_type.css` and components from `ui_kits/`. If working on production code, copy assets and read the rules in README.md to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design (mobile screen? admin view? marketing slide? landing page?), ask clarifying questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
